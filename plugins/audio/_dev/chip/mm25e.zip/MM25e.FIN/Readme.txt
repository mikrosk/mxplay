**************************************************************************************************************************
***********************
*** Music-Mon V2.5e ***
***********************

Release-Date 24.11.2007 

*** Bugfixes ***

* Replay / SNDH / Editor : 

	Playback of 100Hz and especially 200Hz Sounds sligthly pitched down sample-playback on 8 MHz machines
 	due to timing issues

* Editor:

	"SAVE ALL" and "SAVE PATTERN" introduced 32 Bytes of $0F Bytes at the beginning of each sample on every save process
	accumulating to a clearly noticeable silence after several save/load attempts (that's an embarassing one)

Thanks to stu calling my attention to both of these bugs.


***********************
*** Music-Mon V2.5d ***
***********************

Release-Date 26.04.2006 

*** New Features ***

* Editor:

	"Song-Pos down" button clicked on Song-Pos 00 wraps around to the last 
	song-position now.

*** Bugfixes ***

* Replay / SNDH / Editor : 

	Upper limit frequency clipping (e.g. on slides up) on 4-,8-,16-step Sid-Waves was 
	buggy which due to another bug lead to different results in editor and replay routine. 
	Problem has been fixed at its root (corrected clipping) which might affect existing 
	tracks slightly. Example track which shows up the bug : shortro.sng from schmx, slide 
	beginning on pattern 07, sound #11. This track is one of MM2.5 demo tracks.

***********************
*** Music-Mon V2.5c ***
***********************

Release-Date 14.03.2006 

*** Bugfixes ***

* Replay : Wrong timing on tracks using different pattern speeds:
           Step 000 of a pattern had still the timing of the previous pattern
* Editor : SNDH export implicitely affected by the replay bug since replay included in every SNDH module

***********************
*** Music-Mon V2.5b ***
***********************

Release-Date 04.03.2006 

* New hints in this readme.txt

*** Bugfixes ***

* Replay : Fading was not reset on calling INIT1 again
* Editor : Editor crashed with 2 Bombs when saving a MOD/SNDH that uses empty digi-sounds

**************************************************************************************************************************
***********************
*** Music-Mon V2.5a ***
***********************

Release-Date 24.12.2005 (not joking!)

* Correction : Sync-Buzzers are now tuned as in 2.1 again

**************************************************************************************************************************
**********************
*** Music-Mon V2.5 ***
**********************

Release-Date 24.12.2005

*** New Features of Music-Mon 2.5 Editor ***

+ 2 digi-channels
+ free SID waveforms with up to 16 steps
+ create 8-step and 16-step SID sine-wave by just a mouse click
+ maximum pattern length now 128
+ speed can now be set for each pattern individually
+ increased sound capacity to 100
+ increased pattern capacity to 100
+ Direct SNDH export
+ Portamento realized as a third pitch bend mode
+ SID Main- and Fine-Tune
+ Pitchbend and PMD can now also be applied to SID
+ Arpeggio can now be selectively applied to SID
+ SID intensity modulation
+ Configuration file to preset some settings on startup
+ Digi-Notes can now be also entered via MIDI
+ New multi timbrale MIDI Mode with adjustable base channel (To be found in the tools menu of the song screen)
+ S/D can now be toggled not only by shortcut '~' but also by mouse
+ Direct Entry Mode (Enter) can now be canceled with the ESC key
+ Entry of a filename in fileselector can now be canceled with ESC key
+ More convenient filename backups/proposals in fileselector
+ When saving MODs and SNDH the sound names (synth + digi) are optionally deposited in the file. Good for jukebox
  stuff.
+ Tremendous speed up in saving a module (+sndh)

*** New shortcuts ***

+ Ctrl + 'X' : expands the pattern : doubles the length and uncompresses the notes 
+ Shift + 'X' : expands the upper half of the current channel
+ Shift + 'N' : jump to next unused pattern
+ Control + 'N' : jump to next used pattern
+ Control + 'W' : copy buffer to channel incl. pattern speed

*** Bugfixes in Music-Mon 2.5 Editor ***

+ Bugfix (since 2.0 SID): Glitches on particular sequences of digis and normal sounds
+ Bugfix (since 2.0): CLR HME (select sound) didn't work for C#5 notes
+ Bugfix (since 1.0): MM did refuse to start when Falcon directly booted with low or mid-res
+ Bugfix (since 2.1): Sync Buzzer sounds did affect buzzer sounds on other channels differently when channel muted
+ Bugfix (since 1.0) : SAVE ALL now saves also nameless but modified sounds
+ Bugfix (since 1.0) : SAVE ALL now saves also empty but used patterns (important regarding speed/length)
+ Bugfix (since 1.0) : Pitchbend Offset (N) was coarse grained (Bits 0,1 were always zero). Now full resolution.

*** New Features of Music-Mon 2.5 Replay ***

+ Of course, supporting all new features of the V2.5 editor sound engine. 
+ No more need to copy digi modules in memory, sample conversion now done in place, INIT 2 is history
+ Replay now free from system calls, hence compatible with WinJam etc.
+ Detailed info block provided by replay routine. Allows to create fancy jukeboxes. (Check out the jukebox in Alive #12 which 
  is using this new feature.)
+ Provides an interface to create SNDH header in memory. So you can create your own batch converters.

Details about changes to the replay interface as well as a description about the structure of the new
info block can be found in the separate replay howto.txt. 

------------------------------------------------------------------------------------------------------------------------

Some hints:

1) To get the new SID/SyncB control panel click on the purple 'SID' button with the right mouse button. Some other
   controls will be hidden by the control panel. That means they are just hidden but still active. You can switch back
   to the standard controls by again clicking the 'SID' button.

2) The small green wave button on the SID control menu produces a 16-step sine wave in the wave-field. Clicking with
   the right mouse button produces a 8-step sine wave which sounds not that much different to its 16-step pendant but
   takes only half of CPU and by that allows also higher frequencies.

3) Portamento in conjunction with SID works only correctly in case of
   SID Main-Tune = 0 and '-OKT' is not activated.

4) Pitch Bend Delay works different for PSG square, SID, and Hardwave. For PSG Square, the initial 
   pitch bend offset is not applied before the delay time is over. For SID and hardwave the initial
   pitch bend offset is applied immediately and will not be modified until delay time is over. 
   This fact lleads to a frequency span when using delay. Kept this discrepancy in advantage to
   some funny sounds (one example is sound 00 (accomp) of the demo track Sorn.)

5) New MIDI multi timbrale mode allows to play each YM channel on a separate MIDI channel. On default,
   MIDI Channels 1-3 map to YM Channels A,B,C playing synth notes. MIDI channels 4,5 play digi sounds
   on the according YM channels A,B. The editor reacts on MIDI program change commands so you can change
   the sound for each channel remotely and individually. This new multi mode allows you to use Music-Mon 
   just as a sound generator controlled by an external MIDI sequencer. Since you can switch the sounds anytime 
   you can compose complete tracks with external sequencers. The timing resolution is always 1/50 sec.
   By a parameter in the config file it is also possible to adjust the base channel. This allows to cascade up to 
   3 machines to get 9 YM voices polyphonic! Set the MIDI Base channel to 1 for the first machine, to 6 for the second
   and to 11 on the third. Never tested if that base channel adjustment really works... Scary, isn't it? ;-)

6) SNDH Export will set the following tags:

   TITL Title taken from the Title field
   COMM Taken from the configuration file ("Dark Angel" is default ;-) )
   RIPP Taken from the configuration file ("original" is default)
   CONV implicitely set to "Music-Mon V2.5"
   YEAR Either taken from system time or from configuration file (if set there)
   TIME The actual playtime, automatically calculated

7) There is now a configuration file "settings.cfg" which allows to preset some parameters of the editor
   as well as some of the SNDH tags used when exporting SNDH modules.

	SNDH_COMM defines the composer used on SNDH export
	SNDH_YEAR defines the year used on SNDH export (if not set, system time is used)
	SNDH_RIPP defines the Ripper 

	MIDI_MODE allows to preset the Multi timbral MIDI mode (default is the old OMNI mode (tools menu))
	KEYPAD_MODE allows to preset the KP2 keypad mode (default is KP1 mode (tools menu))
	DIGI_MODE=ON allows to preset the Digi master switch (Tools menu)
	RECORD_MODE=MONITOR allows to preset the monitoring mode when recording (the small purple button above VU meters)
	DEFAULT_SPEED allows to preset a default speed given to all patterns on startup
	MIDI_BASECHANNEL allows to adjust the MIDI base channel for multi timbrale mode (see also above)

   Note : It is important that the file ends with a CR! (lame, but true ;-) )

   Of course, this package includes a sample config file.

8) Sometimes I guess that some of Music-Mon's features accessable only by right mouse button clicks
   have been forgotten (even by myself ;-) ). Hence, here a (hopefully complete) list of features accessable
   by right mouse button clicks on the according buttons:

   * SID-Button : Shows/Hides SID/SyncB Control Panel
   * Green Wave-Button on SID Control Panel : Create 8-step wave instead of 16-step one
   * Sound X->Y (tools menu) : Apply on all 3 channels instead of only current channel
   * Transpose up/down (tools menu) : Apply on all 3 channels instead of only current channel
   * Pattern-Button : Start replay at current cursor position
   * Play from/to Buttons : Start replay at current pattern and cursor position 
   * Play Song-Button : Start replay at current sequencer position
   * Load ALL/Song Buttons : Append song to existing one. Patterns will be loaded starting at current
     set pattern#, synth sounds will be loaded starting at the current set sound#, digis accordingly. A warning
     will appear when not all entities fit into memory. Of course, the sound# in the loaded patterns will be
     adapted accordingly.
   * Save MOD / SNDH Buttons : Omit storing synth sound and digi sound names within the module
   * Soundname field (song- and sound screen) (hold down mouse button): Select sound via list selector
   * Load / Pattern : Load only the actual pattern data, not the sounds
   * Load / SAM : When loading raw samples sample data is expected in 8Bit unsigned format (otherwise 8Bit signed)
   * Clear Song (tools menu) : Keep the synth and digi sounds
   * All up/down buttons on sound screen : Faster adjustment

9) Other features which are a little bit subtile:

   * LOAD / KIT allows you to extract also the sounds from a song. Just change the EXT in the fileselector
     to SNG and select a song from which the sounds shall be extracted.


Now enjoy this new release! If you want do me a favour send me your creations from time to time.
This motivates me in doing another release!

Bests,
	DA


**************************************************************************************************************************
***********************
*** Music-Mon V2.1b ***
***********************

Release-Date 12.09.2005

Sorry folks, I didn't test the V2.1a editor on real machines... 
Stu just gave me a hint that on real machines (Mega STE, Falcon)
the fileselector does not show any files anymore... 

This is now corrected!

This version also fixes another bug which already existed in V2.0:

SHIFT + CLR HOME (Change Sound X --> ACTUAL (S/D)) didn't work
on C#5 notes (crazy, but true).



Have fun,
	  DA

**************************************************************************************************************************
***********************
*** Music-Mon V2.1a ***
***********************

Release-Date 21.08.2005

This is a bugfixed version of Music-Mon V2.1 which had been released 
on 06.02.2005. 

Bugfixes are basically concerning the replay routine, but also the 
editor got a bugfix:

Replay:

	1) Timing regarding 50/100/200Hz sounds was wrong in 
           some constellations
	2) triangle waveform of AMD (S+N) was incorrect
	3) triangle waveform of PMD (WAVE) was incorrect

	These bugs existed already in the 2.0 replay. A new version of
        the replay fixing these bugs had been released on 07.07.2005 
	on DHS.

	new bugfix of this release:

	4) crashes or freaky noises caused by special constellations
	   where successive digi notes of same sound# without any 
	   synth-note between on Channel A were combined with 
	   Sids / Sync-Buzzers on Channels B and C in a particular
	   sequence. This bug was uncovered by Marcer.

Editor:
	
	1) Filenames with more than one dot in (e.g. Music.sng.bak) 
	   confused the file-selector. Filenames with multiple dots in 
	   are actually only possible in emulation environments so this 
	   is not an issue on real machines (at least the traditional ones). 


-------------------------------------------------------------------------------------------

Transcript of the scroller text:

"Hi folks, just some weeks after the release of MusicMon 2.0 SID 
here is the next one with the following new features: 

	* Sync-Buzzers 

	* Improved SID syncing 

	* Range of PMD Hardwave Depth extended to 63 (previously 15) 

	* Pitch-Bend can now be applied also to Hardwave (very important for 
	  sync-buzzers but also usefull for normal buzzers) 

	* Overlay/Underlay Paste Feature (SHIFT + 'U' / 'O') 

	* Entering of song- and soundname can now be canceled by 'ESC' key 
	  (small issue but it was just nasty when accidentally klicking into the 
	   sound/song name field with left instead of right mouse-key) 

	* Starts also from ST med res now

	* Support of 'Install Application...' (.SNG extension)

	* SMC-free replay routine with free configurable timer use 

	* 100% backward compatible to all previous MusicMon versions 

Small introduction:          

The hardwave menu offers a new sync alternative activated by the new purple
button 'S. 3'. Once activated it applies periodically sync on hardwave 
providing the sync buzzer effect. The frequency of the sync generator
behaves in the same way as the SID square generator does (but is driven 
one octave lower). Same as for SID generator, only Arpeggio affects the
generator frequency, but Pitch Bend or PMD do not. Sync Buzzer feature 
cannot be combined with SID so activating 'S. 3' automagically switches
off SID and vice versa. 

Most important on Sync-Buzzer sounds is smart modulation of hardwave 
frequency as you surely know already. So now, the pitch bend generator
can also be applied to the hardwave by the new button 'A.P.B.' 
(Apply Pitch Bend). The Frequency offset of pitch-bend is divided by 16
to achieve a match with the PSG square frequency (so slides of normal 
buzzer sounds sound also correctly). That means, a speed of 16 
corresponds to a continous frequency slide each 1/50 s, 1/100 s, 1/200 s.          
Beyond that, the PMD Depth for Hardwave has been extended to 63 which 
provides also additional possibilities. 

It's worth experimenting with fixed hardwave-frequency or high 
main-tune values also... You can also produce interesting arpeggio sounds...

Thanks to gwem and tao for providing me some hints regarding 
the sync buzzer effect...           

Thanks to stu for intensive beta testing...

Thanks to stu, drx, Marcer and Nexus 6 for donating demo songs...                     

Thanks to Cyclone for assisting me in switching the screen resolution
and sending me a code snippet about fetching command line arguments...

Some words about the replay routine:        

The focus was to deliver a system friendly routine running on any machine.
Regarding performance there is some room for improvement. So if you have 
a particular need for squeezing out the last cycle out of it you might 
convince me to provide customized versions using SMC and/or reserved 
registers...      

Ok, that's all for now... Have fun! And watch out for forthcoming 
releases which maybe will come..."


Dark Angel 
	alias
	    Frank Lautenbach

